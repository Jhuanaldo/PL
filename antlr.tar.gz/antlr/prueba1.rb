puts 'Hola, cuál es tu nombre?'
STDOUT.flush
nombre = gets.chomp
puts 'Hola, ' + nombre + '.'
 
if nombre == "entra"; 
  puts 'Pedazo de nombre!!!'
else
  if name == 'Enjuto' then
    puts '...este nombre no es moco de pavo...'
  end
end

case nombre
 when "Eimard"; 
puts "hola"
when "otro" then
end

