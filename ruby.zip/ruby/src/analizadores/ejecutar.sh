rm Yylex.java parser.java Sym.java *class *~
jflex *.flex
cup *.cup
javac *.java
