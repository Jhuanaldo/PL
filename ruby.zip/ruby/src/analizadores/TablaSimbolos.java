/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analizadores;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;

/**
 *
 * @author ordenador
 */
public class TablaSimbolos {

    private Stack<Hashtable<String, Expresion>> tablas;

    public TablaSimbolos() {
        tablas = new <Hashtable<String, Expresion>>Stack();
        tablas.add(new Hashtable<String, Expresion>());
    }

    public void insertar(String nombre, Expresion valor) {
        Hashtable aux=this.getTabla();
        tablas.pop();
        if(aux.get(nombre)==null || (!tablas.empty()&&tablas.peek().get(nombre)==aux.get(nombre))){
            this.getTabla().put(nombre, valor);
            //se inserta si no esta declarada
            //si esta declarada puede ser declarada nuevamente, solo para ese bloque
        }else{
            //Error variable ya declarada
            
        }
        tablas.push(aux);
    }

    public Expresion get(String nombre) {
        return (Expresion) this.getTabla().get(nombre);
    }

    public Hashtable getTabla() {
        return tablas.peek();
    }

    public void pushTabla() {
        tablas.push((Hashtable) copiaTabla());
    }

    public Hashtable popTabla() {
        return tablas.pop();
    }
    
    public String toString(){
        return "hola PUTO Eusebio";
    }

    private Hashtable copiaTabla() {
        Hashtable<String,Expresion> t =new Hashtable();
        String llave;
        for (Enumeration<String> e = this.getTabla().keys(); e.hasMoreElements();){
            llave=e.nextElement();
            t.put(llave, (Expresion) this.getTabla().get(llave));  //los valores se pasan por referencia
        }
        return t;
    }

}
